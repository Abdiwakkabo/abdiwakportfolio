document.getElementById("contactForm").addEventListener("submit", function (e) {
    e.preventDefault(); // Prevent the form from submitting

    // You can perform further actions here, like sending the form data to a server


});
